package com.neurogine.product.demo;

import com.neurogine.product.demo.entity.Product;
import com.neurogine.product.demo.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class ProductDemoApplication implements ApplicationRunner {
	@Autowired
	private ProductRepository productRepository;
	public static void main(String[] args) {
		SpringApplication.run(ProductDemoApplication.class, args);
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		List<Product> products = new ArrayList<>();
		for (int i = 0; i <20 ; i++) {
			products.add(new Product((long) i,"product"+i, "The best product in the compnay for "+i +"Years",100+i));
		}
		productRepository.saveAll(products);
	}
}
