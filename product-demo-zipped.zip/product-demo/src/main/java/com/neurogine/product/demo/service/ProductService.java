package com.neurogine.product.demo.service;

import com.neurogine.product.demo.dto.ProductRequest;
import com.neurogine.product.demo.entity.Product;
import com.neurogine.product.demo.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;

    public Product findProductByName (String productName){
        return productRepository.findByProductName(productName);
    }

    public void saveProduct(ProductRequest request) {
        Product product = productRepository.findByProductName(request.getProductName());
        if(null != product){// if the product already exist we just need to update
            product.setProductName(request.getProductName());
            product.setProductDescription(request.getProductDescription());
            product.setPrice(request.getPrice());
            productRepository.save(product);
        }else{// otherwise create the user
            Product newproduct = new Product();
            productRepository.save(newproduct);
        }

    }
    public List<Product> getAllproducts(){
        return productRepository.findAll();
    }

}
