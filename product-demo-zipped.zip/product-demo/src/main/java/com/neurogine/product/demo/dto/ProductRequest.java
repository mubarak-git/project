package com.neurogine.product.demo.dto;

import javax.validation.constraints.Size;

public class ProductRequest {
    @Size(min=4, max=50)
    private String productName;
    @Size(min=10, max=255)
    private String productDescription;
    private double price;

    public ProductRequest() {
    }

    public ProductRequest(String productName, String productDescription, double price) {
        this.productName = productName;
        this.productDescription = productDescription;
        this.price = price;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
