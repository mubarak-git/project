package com.neurogine.product.demo;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class APIAuditAspect {

	@AfterThrowing(
			pointcut = "execution(* com.neurogine.product.demo.service.MerchantService))",
			throwing = "exception")
	public void auditingAfterThrowingException(JoinPoint joinPoint,
								 Throwable exception)
	{
		System.out.print("auditingAfterThrowingException is running!");
		System.out.println(
				", after " + joinPoint.getSignature().getName()
						+ " method throwing exception");
		System.out.println("exception = " + exception);
		System.out.println("******");
	}
}
