package com.neurogine.product.demo.controller;

import com.neurogine.product.demo.dto.ProductRequest;
import com.neurogine.product.demo.dto.ProductResponse;
import com.neurogine.product.demo.entity.Product;
import com.neurogine.product.demo.service.ProductService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/api/v1")
public class ProductController {
    private final Logger log = (Logger) LoggerFactory.getLogger(ProductController.class);
    @Autowired
    ProductService productService;

    /**
     * This method is created to product
     */
    @GetMapping("/product")
    public ResponseEntity<ProductResponse> getFeatureStatusByEmailAndName(
            @RequestParam(required = true) String productName) {
        Optional<Product> product = Optional.ofNullable(productService.findProductByName(productName));
        return (ResponseEntity) product.map((p) -> {
            ProductResponse response = new ProductResponse();
            response.setProductName(p.getProductName());
            response.setPrice(p.getPrice());
            response.setProductDescription(p.getProductDescription());
            return ((ResponseEntity.BodyBuilder) ResponseEntity.ok()).body(response);
        }).orElseThrow(() -> {
            return new ResponseStatusException(HttpStatus.NOT_FOUND);
        });
    }

    /**
     * @param request which is the feature name and email and enable or disable
     * @return success 200 or 304 not modifiable
     */
    @PostMapping("/product")
    public ResponseEntity<ProductResponse> createFeature(@Valid @RequestBody ProductRequest request) {
        try {
            productService.saveProduct(request);
            return ResponseEntity.status(HttpStatus.OK).build();
        } catch (Exception ex) {
            log.error(ex.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @GetMapping("/allproducts")
    public ResponseEntity<List<ProductResponse>> getAllProducts() {
        List<Product> products = productService.getAllproducts();
        List<ProductResponse> productList = new ArrayList<>();
        products.forEach(product -> {
            ProductResponse p = new ProductResponse();
                    p.setProductName(product.getProductName());
                    p.setProductDescription(product.getProductDescription());
                    p.setPrice(product.getPrice());
                    productList.add(p);
                }
        );
        return ((ResponseEntity.BodyBuilder) ResponseEntity.ok()).body(productList);
    }
}